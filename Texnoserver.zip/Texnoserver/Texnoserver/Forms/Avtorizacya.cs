﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Texnoserver.Model1;
using Texnoserver.Forms;

namespace Texnoserver
{
    public partial class Avtorizacya : Form
    {
        public Avtorizacya()
        {
            InitializeComponent();
            this.Font = new Font("Comic Sans MS", 14, FontStyle.Bold);
        }


        private void btCfncel_Click(object sender, EventArgs e)
        {
            tblogin.Clear();
            tbpass.Clear();
            MessageBox.Show("Поля очищены");

        }

        private void Avtorizacya_FormClosing(object sender, FormClosingEventArgs e)
        {
            //DialogResult sd = MessageBox.Show("Вы дествительно хотите выйти?", "Выход", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
            ////if (sd == DialogResult.Cancel) e.Cancel = true;
            //if (sd==DialogResult.OK)
            Application.Exit();

        }

        private void btKl_Click(object sender, EventArgs e)
        {

            try
            {
                List<Users> users = texnoserverEntities1.GetContext().Users.ToList();
                Users u = users.FirstOrDefault(p => p.Login == tblogin.Text && p.Password == tbpass.Text);

                if (u != null)
                { if (u.Id == 1)
                    {
                        Sodrudnic sodrudnic = new Sodrudnic();
                        sodrudnic.Owner = this;
                        this.Hide();
                        sodrudnic.Show();
                    }
                    else if (u.Id == 2)
                    {
                        Forms.Klient klient = new  Forms.Klient();
                       klient.Owner = this;
                        this.Hide();
                        klient.Show();
                    }
                }
                else
                {
                    MessageBox.Show("Не верный логин или пароль");

                }
                }
                catch(Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
            }
  //          string login = tblogin.Text;
  //          string password = tbpass.Text;

  //          if (login == "admin" && password == "123")
  //          {
  //              Sodrudnic sodrudnic = new Sodrudnic();
  //              //sodrudnic.Owner = this;
  //              this.Hide();
  //              sodrudnic.Show();

  //          }
  //          else
            
  //              if (login == "users" && password == "123")
  //{
  //                  Klient klient = new Klient();
  //                  //klient.Owner = this;
  //                  this.Hide();
  //                  klient.Show();
  //              }

            

            }
        }
    
