﻿
namespace Texnoserver
{
    partial class Avtorizacya
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.lbname = new System.Windows.Forms.Label();
            this.LbOrg = new System.Windows.Forms.Label();
            this.btKl = new System.Windows.Forms.Button();
            this.lbogin = new System.Windows.Forms.Label();
            this.lbpass = new System.Windows.Forms.Label();
            this.tblogin = new System.Windows.Forms.TextBox();
            this.tbpass = new System.Windows.Forms.TextBox();
            this.btCfncel = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.panel1.Controls.Add(this.LbOrg);
            this.panel1.Controls.Add(this.lbname);
            this.panel1.Location = new System.Drawing.Point(0, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(519, 96);
            this.panel1.TabIndex = 0;
            // 
            // lbname
            // 
            this.lbname.AutoSize = true;
            this.lbname.Location = new System.Drawing.Point(236, 35);
            this.lbname.Name = "lbname";
            this.lbname.Size = new System.Drawing.Size(70, 13);
            this.lbname.TabIndex = 0;
            this.lbname.Text = "Учет заявок";
            // 
            // LbOrg
            // 
            this.LbOrg.AutoSize = true;
            this.LbOrg.Location = new System.Drawing.Point(215, 64);
            this.LbOrg.Name = "LbOrg";
            this.LbOrg.Size = new System.Drawing.Size(110, 13);
            this.LbOrg.TabIndex = 1;
            this.LbOrg.Text = "ООО \"Техносервис\"";
            // 
            // btKl
            // 
            this.btKl.Location = new System.Drawing.Point(103, 237);
            this.btKl.Name = "btKl";
            this.btKl.Size = new System.Drawing.Size(123, 23);
            this.btKl.TabIndex = 1;
            this.btKl.Text = "Войти";
            this.btKl.UseVisualStyleBackColor = true;
            this.btKl.Click += new System.EventHandler(this.btKl_Click);
            // 
            // lbogin
            // 
            this.lbogin.AutoSize = true;
            this.lbogin.Location = new System.Drawing.Point(120, 145);
            this.lbogin.Name = "lbogin";
            this.lbogin.Size = new System.Drawing.Size(38, 13);
            this.lbogin.TabIndex = 2;
            this.lbogin.Text = "Логин";
            // 
            // lbpass
            // 
            this.lbpass.AutoSize = true;
            this.lbpass.Location = new System.Drawing.Point(120, 189);
            this.lbpass.Name = "lbpass";
            this.lbpass.Size = new System.Drawing.Size(45, 13);
            this.lbpass.TabIndex = 3;
            this.lbpass.Text = "Пароль";
            // 
            // tblogin
            // 
            this.tblogin.Location = new System.Drawing.Point(218, 137);
            this.tblogin.Name = "tblogin";
            this.tblogin.Size = new System.Drawing.Size(100, 20);
            this.tblogin.TabIndex = 4;
            // 
            // tbpass
            // 
            this.tbpass.Location = new System.Drawing.Point(218, 182);
            this.tbpass.Name = "tbpass";
            this.tbpass.Size = new System.Drawing.Size(100, 20);
            this.tbpass.TabIndex = 5;
            // 
            // btCfncel
            // 
            this.btCfncel.Location = new System.Drawing.Point(265, 237);
            this.btCfncel.Name = "btCfncel";
            this.btCfncel.Size = new System.Drawing.Size(97, 23);
            this.btCfncel.TabIndex = 6;
            this.btCfncel.Text = "Отмена";
            this.btCfncel.UseVisualStyleBackColor = true;
            this.btCfncel.Click += new System.EventHandler(this.btCfncel_Click);
            // 
            // Avtorizacya
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(519, 308);
            this.Controls.Add(this.btCfncel);
            this.Controls.Add(this.tbpass);
            this.Controls.Add(this.tblogin);
            this.Controls.Add(this.lbpass);
            this.Controls.Add(this.lbogin);
            this.Controls.Add(this.btKl);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Avtorizacya";
            this.Text = "Авторизация";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Avtorizacya_FormClosing);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label LbOrg;
        private System.Windows.Forms.Label lbname;
        private System.Windows.Forms.Button btKl;
        private System.Windows.Forms.Label lbogin;
        private System.Windows.Forms.Label lbpass;
        private System.Windows.Forms.TextBox tblogin;
        private System.Windows.Forms.TextBox tbpass;
        private System.Windows.Forms.Button btCfncel;
    }
}

