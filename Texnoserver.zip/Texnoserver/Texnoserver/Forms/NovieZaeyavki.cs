﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Texnoserver.Forms
{
    public partial class NovieZaeyavki : Form
    {
        public NovieZaeyavki()
        {
            InitializeComponent();
        }

        private void btOtmena_Click(object sender, EventArgs e)
        {
            
            tbOpicanie.Clear();
            MessageBox.Show("Поля очищены");
        }

        private void btNazad_Click(object sender, EventArgs e)
        {
            Avtorizacya av = new Avtorizacya();
            this.Hide();
            av.ShowDialog();
        }
    }
}
