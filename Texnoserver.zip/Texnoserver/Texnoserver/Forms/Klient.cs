﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Texnoserver.Forms
{
    public partial class Klient : Form
    {
        public Klient()
        {
            InitializeComponent();
        }

        private void la_Click(object sender, EventArgs e)
        {

        }

        private void btdob_Click(object sender, EventArgs e)
        {
            NovieZaeyavki novieZaeavki = new NovieZaeyavki();
            novieZaeavki.Show();
            this.Close();
        }

        private void BtCfncel_Click(object sender, EventArgs e)
        {
            Avtorizacya av = new Avtorizacya();

            this.Hide();
            av.ShowDialog();
        }
    }
}
