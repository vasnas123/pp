﻿
namespace Texnoserver.Forms
{
    partial class Klient
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbrezult = new System.Windows.Forms.Label();
            this.BtCfncel = new System.Windows.Forms.Button();
            this.la = new System.Windows.Forms.Label();
            this.btdob = new System.Windows.Forms.Button();
            this.DgvZayavki = new System.Windows.Forms.DataGridView();
            this.panel1 = new System.Windows.Forms.Panel();
            this.LbOrg = new System.Windows.Forms.Label();
            this.lbname = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.DgvZayavki)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbrezult
            // 
            this.lbrezult.AutoSize = true;
            this.lbrezult.Location = new System.Drawing.Point(425, 416);
            this.lbrezult.Name = "lbrezult";
            this.lbrezult.Size = new System.Drawing.Size(0, 13);
            this.lbrezult.TabIndex = 15;
            // 
            // BtCfncel
            // 
            this.BtCfncel.Location = new System.Drawing.Point(521, 114);
            this.BtCfncel.Name = "BtCfncel";
            this.BtCfncel.Size = new System.Drawing.Size(111, 23);
            this.BtCfncel.TabIndex = 14;
            this.BtCfncel.Text = "Назад";
            this.BtCfncel.UseVisualStyleBackColor = true;
            this.BtCfncel.Click += new System.EventHandler(this.BtCfncel_Click);
            // 
            // la
            // 
            this.la.AutoSize = true;
            this.la.Location = new System.Drawing.Point(40, 119);
            this.la.Name = "la";
            this.la.Size = new System.Drawing.Size(61, 13);
            this.la.TabIndex = 9;
            this.la.Text = "Мои завки";
            this.la.Click += new System.EventHandler(this.la_Click);
            // 
            // btdob
            // 
            this.btdob.Location = new System.Drawing.Point(314, 411);
            this.btdob.Name = "btdob";
            this.btdob.Size = new System.Drawing.Size(111, 23);
            this.btdob.TabIndex = 11;
            this.btdob.Text = "Добавить";
            this.btdob.UseVisualStyleBackColor = true;
            this.btdob.Click += new System.EventHandler(this.btdob_Click);
            // 
            // DgvZayavki
            // 
            this.DgvZayavki.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvZayavki.Location = new System.Drawing.Point(29, 143);
            this.DgvZayavki.Name = "DgvZayavki";
            this.DgvZayavki.Size = new System.Drawing.Size(630, 234);
            this.DgvZayavki.TabIndex = 10;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.panel1.Controls.Add(this.LbOrg);
            this.panel1.Controls.Add(this.lbname);
            this.panel1.Location = new System.Drawing.Point(3, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(697, 96);
            this.panel1.TabIndex = 8;
            // 
            // LbOrg
            // 
            this.LbOrg.AutoSize = true;
            this.LbOrg.Location = new System.Drawing.Point(289, 51);
            this.LbOrg.Name = "LbOrg";
            this.LbOrg.Size = new System.Drawing.Size(110, 13);
            this.LbOrg.TabIndex = 1;
            this.LbOrg.Text = "ООО \"Техносервис\"";
            // 
            // lbname
            // 
            this.lbname.AutoSize = true;
            this.lbname.Location = new System.Drawing.Point(312, 27);
            this.lbname.Name = "lbname";
            this.lbname.Size = new System.Drawing.Size(70, 13);
            this.lbname.TabIndex = 0;
            this.lbname.Text = "Учет заявок";
            // 
            // Klient
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(712, 450);
            this.Controls.Add(this.lbrezult);
            this.Controls.Add(this.BtCfncel);
            this.Controls.Add(this.la);
            this.Controls.Add(this.btdob);
            this.Controls.Add(this.DgvZayavki);
            this.Controls.Add(this.panel1);
            this.Name = "Klient";
            this.Text = "Klient";
            ((System.ComponentModel.ISupportInitialize)(this.DgvZayavki)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbrezult;
        private System.Windows.Forms.Button BtCfncel;
        private System.Windows.Forms.Label la;
        private System.Windows.Forms.Button btdob;
        private System.Windows.Forms.DataGridView DgvZayavki;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label LbOrg;
        private System.Windows.Forms.Label lbname;
    }
}