﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Texnoserver.Forms
{
    public partial class Sodrudnic : Form
    {
        public Sodrudnic()
        {
            InitializeComponent();
            this.Font = new Font("Comic Sans MS", 14, FontStyle.Bold);
        }

        private void Sodrudnic_Load(object sender, EventArgs e)
        {

        }

        private void BtCfncel_Click(object sender, EventArgs e)
        {
            Avtorizacya av = new Avtorizacya();
           
           this.Hide();
            av.ShowDialog();

        }

        private void lbrezult_Click(object sender, EventArgs e)
        {

        }

        private void la_Click(object sender, EventArgs e)
        {

        }

        private void btraschet_Click(object sender, EventArgs e)
        {

        }

        private void btredak_Click(object sender, EventArgs e)
        {

        }

        private void btdob_Click(object sender, EventArgs e)
        {

        }

        private void DgvZayavki_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
