﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Texnoserver.Forms;

namespace Texnoserver
{
    public partial class Avtorizacya : Form
    {
        public Avtorizacya()
        {
            InitializeComponent();
            this.Font = new Font("Comic Sans MS", 14, FontStyle.Bold);
        }

        private void btCfncel_Click(object sender, EventArgs e)
        {
            tblogin.Clear();
            tbpass.Clear();
            MessageBox.Show("Поля очищены");
            
        }

        private void Avtorizacya_FormClosing(object sender, FormClosingEventArgs e)
        {
            //DialogResult sd = MessageBox.Show("Вы дествительно хотите выйти?", "Выход", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
            ////if (sd == DialogResult.Cancel) e.Cancel = true;
            //if (sd==DialogResult.OK)
            Application.Exit();
           
        }

        private void btKl_Click(object sender, EventArgs e)
        {
            string login = tblogin.Text;
            string password = tbpass.Text;

            if (login == "admin" && password == "123")
            {
                Sodrudnic sodrudnic = new Sodrudnic();
                sodrudnic.Owner = this;
                this.Hide();
                sodrudnic.Show();
                
            }

        }
    }
}
