﻿
namespace Texnoserver.Forms
{
    partial class Sodrudnic
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.LbOrg = new System.Windows.Forms.Label();
            this.lbname = new System.Windows.Forms.Label();
            this.DgvZayavki = new System.Windows.Forms.DataGridView();
            this.btdob = new System.Windows.Forms.Button();
            this.btredak = new System.Windows.Forms.Button();
            this.btraschet = new System.Windows.Forms.Button();
            this.la = new System.Windows.Forms.Label();
            this.BtCfncel = new System.Windows.Forms.Button();
            this.lbrezult = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvZayavki)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.panel1.Controls.Add(this.LbOrg);
            this.panel1.Controls.Add(this.lbname);
            this.panel1.Location = new System.Drawing.Point(0, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(646, 96);
            this.panel1.TabIndex = 1;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // LbOrg
            // 
            this.LbOrg.AutoSize = true;
            this.LbOrg.Location = new System.Drawing.Point(234, 61);
            this.LbOrg.Name = "LbOrg";
            this.LbOrg.Size = new System.Drawing.Size(110, 13);
            this.LbOrg.TabIndex = 1;
            this.LbOrg.Text = "ООО \"Техносервис\"";
            // 
            // lbname
            // 
            this.lbname.AutoSize = true;
            this.lbname.Location = new System.Drawing.Point(255, 31);
            this.lbname.Name = "lbname";
            this.lbname.Size = new System.Drawing.Size(70, 13);
            this.lbname.TabIndex = 0;
            this.lbname.Text = "Учет заявок";
            // 
            // DgvZayavki
            // 
            this.DgvZayavki.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvZayavki.Location = new System.Drawing.Point(12, 140);
            this.DgvZayavki.Name = "DgvZayavki";
            this.DgvZayavki.Size = new System.Drawing.Size(623, 234);
            this.DgvZayavki.TabIndex = 2;
            this.DgvZayavki.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DgvZayavki_CellContentClick);
            // 
            // btdob
            // 
            this.btdob.Location = new System.Drawing.Point(12, 406);
            this.btdob.Name = "btdob";
            this.btdob.Size = new System.Drawing.Size(104, 23);
            this.btdob.TabIndex = 3;
            this.btdob.Text = "Добавить";
            this.btdob.UseVisualStyleBackColor = true;
            this.btdob.Click += new System.EventHandler(this.btdob_Click);
            // 
            // btredak
            // 
            this.btredak.Location = new System.Drawing.Point(157, 406);
            this.btredak.Name = "btredak";
            this.btredak.Size = new System.Drawing.Size(104, 23);
            this.btredak.TabIndex = 4;
            this.btredak.Text = "Редактировать ";
            this.btredak.UseVisualStyleBackColor = true;
            this.btredak.Click += new System.EventHandler(this.btredak_Click);
            // 
            // btraschet
            // 
            this.btraschet.Location = new System.Drawing.Point(531, 380);
            this.btraschet.Name = "btraschet";
            this.btraschet.Size = new System.Drawing.Size(104, 49);
            this.btraschet.TabIndex = 5;
            this.btraschet.Text = "Расчет выполненных завок ";
            this.btraschet.UseVisualStyleBackColor = true;
            this.btraschet.Click += new System.EventHandler(this.btraschet_Click);
            // 
            // la
            // 
            this.la.AutoSize = true;
            this.la.Location = new System.Drawing.Point(12, 114);
            this.la.Name = "la";
            this.la.Size = new System.Drawing.Size(63, 13);
            this.la.TabIndex = 2;
            this.la.Text = "Сотрудник:";
            this.la.Click += new System.EventHandler(this.la_Click);
            // 
            // BtCfncel
            // 
            this.BtCfncel.Location = new System.Drawing.Point(509, 109);
            this.BtCfncel.Name = "BtCfncel";
            this.BtCfncel.Size = new System.Drawing.Size(104, 23);
            this.BtCfncel.TabIndex = 6;
            this.BtCfncel.Text = "Назад";
            this.BtCfncel.UseVisualStyleBackColor = true;
            this.BtCfncel.Click += new System.EventHandler(this.BtCfncel_Click);
            // 
            // lbrezult
            // 
            this.lbrezult.AutoSize = true;
            this.lbrezult.Location = new System.Drawing.Point(406, 406);
            this.lbrezult.Name = "lbrezult";
            this.lbrezult.Size = new System.Drawing.Size(0, 13);
            this.lbrezult.TabIndex = 7;
            this.lbrezult.Click += new System.EventHandler(this.lbrezult_Click);
            // 
            // Sodrudnic
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(647, 480);
            this.Controls.Add(this.lbrezult);
            this.Controls.Add(this.BtCfncel);
            this.Controls.Add(this.la);
            this.Controls.Add(this.btraschet);
            this.Controls.Add(this.btredak);
            this.Controls.Add(this.btdob);
            this.Controls.Add(this.DgvZayavki);
            this.Controls.Add(this.panel1);
            this.Name = "Sodrudnic";
            this.Text = "Заявки";
            this.Load += new System.EventHandler(this.Sodrudnic_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvZayavki)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label LbOrg;
        private System.Windows.Forms.Label lbname;
        private System.Windows.Forms.DataGridView DgvZayavki;
        private System.Windows.Forms.Button btdob;
        private System.Windows.Forms.Button btredak;
        private System.Windows.Forms.Button btraschet;
        private System.Windows.Forms.Label la;
        private System.Windows.Forms.Button BtCfncel;
        private System.Windows.Forms.Label lbrezult;
    }
}