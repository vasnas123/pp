﻿
namespace Texnoserver.Forms
{
    partial class NovieZaeyavki
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gbZayavka = new System.Windows.Forms.GroupBox();
            this.lbData = new System.Windows.Forms.Label();
            this.dtData = new System.Windows.Forms.DateTimePicker();
            this.lb = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.cbTip = new System.Windows.Forms.ComboBox();
            this.tbOpicanie = new System.Windows.Forms.TextBox();
            this.btCozdat = new System.Windows.Forms.Button();
            this.btOtmena = new System.Windows.Forms.Button();
            this.btNazad = new System.Windows.Forms.Button();
            this.gbZayavka.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbZayavka
            // 
            this.gbZayavka.Controls.Add(this.btOtmena);
            this.gbZayavka.Controls.Add(this.btCozdat);
            this.gbZayavka.Controls.Add(this.tbOpicanie);
            this.gbZayavka.Controls.Add(this.cbTip);
            this.gbZayavka.Controls.Add(this.label2);
            this.gbZayavka.Controls.Add(this.lb);
            this.gbZayavka.Controls.Add(this.dtData);
            this.gbZayavka.Controls.Add(this.lbData);
            this.gbZayavka.Location = new System.Drawing.Point(31, 41);
            this.gbZayavka.Name = "gbZayavka";
            this.gbZayavka.Size = new System.Drawing.Size(314, 273);
            this.gbZayavka.TabIndex = 0;
            this.gbZayavka.TabStop = false;
            this.gbZayavka.Text = "Добавление новой заявки";
            // 
            // lbData
            // 
            this.lbData.AutoSize = true;
            this.lbData.Location = new System.Drawing.Point(6, 44);
            this.lbData.Name = "lbData";
            this.lbData.Size = new System.Drawing.Size(36, 13);
            this.lbData.TabIndex = 1;
            this.lbData.Text = "Дата ";
            // 
            // dtData
            // 
            this.dtData.Location = new System.Drawing.Point(125, 44);
            this.dtData.Name = "dtData";
            this.dtData.Size = new System.Drawing.Size(166, 20);
            this.dtData.TabIndex = 2;
            // 
            // lb
            // 
            this.lb.AutoSize = true;
            this.lb.Location = new System.Drawing.Point(6, 91);
            this.lb.Name = "lb";
            this.lb.Size = new System.Drawing.Size(109, 13);
            this.lb.TabIndex = 5;
            this.lb.Text = "Тип неисправности ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 133);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(112, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Описание проблемы";
            // 
            // cbTip
            // 
            this.cbTip.FormattingEnabled = true;
            this.cbTip.Items.AddRange(new object[] {
            "легко",
            "среднее",
            "сложное"});
            this.cbTip.Location = new System.Drawing.Point(125, 83);
            this.cbTip.Name = "cbTip";
            this.cbTip.Size = new System.Drawing.Size(166, 21);
            this.cbTip.TabIndex = 8;
            // 
            // tbOpicanie
            // 
            this.tbOpicanie.Location = new System.Drawing.Point(125, 130);
            this.tbOpicanie.Multiline = true;
            this.tbOpicanie.Name = "tbOpicanie";
            this.tbOpicanie.Size = new System.Drawing.Size(166, 20);
            this.tbOpicanie.TabIndex = 9;
            // 
            // btCozdat
            // 
            this.btCozdat.Location = new System.Drawing.Point(9, 203);
            this.btCozdat.Name = "btCozdat";
            this.btCozdat.Size = new System.Drawing.Size(117, 27);
            this.btCozdat.TabIndex = 10;
            this.btCozdat.Text = "Создать";
            this.btCozdat.UseVisualStyleBackColor = true;
            // 
            // btOtmena
            // 
            this.btOtmena.Location = new System.Drawing.Point(160, 203);
            this.btOtmena.Name = "btOtmena";
            this.btOtmena.Size = new System.Drawing.Size(117, 27);
            this.btOtmena.TabIndex = 11;
            this.btOtmena.Text = "Очитить";
            this.btOtmena.UseVisualStyleBackColor = true;
            this.btOtmena.Click += new System.EventHandler(this.btOtmena_Click);
            // 
            // btNazad
            // 
            this.btNazad.Location = new System.Drawing.Point(140, 418);
            this.btNazad.Name = "btNazad";
            this.btNazad.Size = new System.Drawing.Size(117, 27);
            this.btNazad.TabIndex = 12;
            this.btNazad.Text = "Назад";
            this.btNazad.UseVisualStyleBackColor = true;
            this.btNazad.Click += new System.EventHandler(this.btNazad_Click);
            // 
            // NovieZaeyavki
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(419, 473);
            this.Controls.Add(this.btNazad);
            this.Controls.Add(this.gbZayavka);
            this.Name = "NovieZaeyavki";
            this.Text = "Добавление новой заявки ";
            this.gbZayavka.ResumeLayout(false);
            this.gbZayavka.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gbZayavka;
        private System.Windows.Forms.Label lbData;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lb;
        private System.Windows.Forms.DateTimePicker dtData;
        private System.Windows.Forms.Button btOtmena;
        private System.Windows.Forms.Button btCozdat;
        private System.Windows.Forms.TextBox tbOpicanie;
        private System.Windows.Forms.ComboBox cbTip;
        private System.Windows.Forms.Button btNazad;
    }
}